<?php


/*
 * Database Configuration
 *
 *  to include this data, include require_once 'config.php';
 * NOT IMPLEMENTED INTO CARD DATABASE
 */

$db_host = '';
$db_user = '';
$db_pass = '';
$db_name = '';
